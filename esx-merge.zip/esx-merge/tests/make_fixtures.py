#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_fixtures — genere deux .esx synthetiques simulant un fork telephone/tablette.

Aucune donnee reelle. Les plans, les AP et les mesures sont inventes, ce qui
permet de tester esx_diff et esx_merge sans manipuler un projet client.

    python tests/make_fixtures.py

Produit dans tests/fixtures/ :
    tablette.esx   projet de base, contient la seconde moitie du site
    telephone.esx  projet d'apport, contient la premiere moitie

Les deux partagent le meme tronc (batiment, etage, plan, types de murs) avec
les memes UUID, ce qui reproduit le cas reel : la tablette est partie d'une
copie du projet telephone, puis les deux ont diverge.

Le scenario embarque volontairement trois situations :
  - des listes serialisees dans un ordre different  -> faux conflits, que la
    comparaison canonique doit absorber
  - un objet partage dont les listes de references divergent reellement
    -> impose --on-conflict union
  - un meme AP vu par les deux terminaux sous deux identifiants differents
    mais avec la meme MAC -> doublon inter-session benin
"""

from __future__ import annotations

import json
import os
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "fixtures")

SCHEMA_VERSION = "1.9.1"

# --- UUID du tronc commun, identiques des deux cotes ------------------------
BUILDING = "11111111-1111-4111-8111-111111111111"
FLOOR = "22222222-2222-4222-8222-222222222222"
FLOORPLAN = "33333333-3333-4333-8333-333333333333"
WALLTYPE_BETON = "44444444-4444-4444-8444-444444444444"
WALLTYPE_PLACO = "55555555-5555-4555-8555-555555555555"
TAGKEY = "66666666-6666-4666-8666-666666666666"

# --- Cote telephone (apport) -------------------------------------------------
TEL_SURVEY = "a0000000-0000-4000-8000-000000000001"
TEL_AP_COMMUN = "a0000000-0000-4000-8000-000000000002"
TEL_AP_PROPRE = "a0000000-0000-4000-8000-000000000003"
TEL_MESURES = [f"a1000000-0000-4000-8000-{i:012d}" for i in range(1, 41)]

# --- Cote tablette (base) ----------------------------------------------------
TAB_SURVEY = "b0000000-0000-4000-8000-000000000001"
TAB_AP_COMMUN = "b0000000-0000-4000-8000-000000000002"
TAB_AP_PROPRE = "b0000000-0000-4000-8000-000000000003"
TAB_MESURES = [f"b1000000-0000-4000-8000-{i:012d}" for i in range(1, 41)]

MAC_PARTAGEE = "00:11:22:33:44:55"


def _project(name: str, pid: str) -> dict:
    return {"id": pid, "name": name, "version": SCHEMA_VERSION}


def _tronc_commun(ordre_inverse: bool, survey_ids: list[str]) -> dict[str, dict]:
    """Objets structurels identiques des deux cotes.

    ordre_inverse serialise certaines listes dans l'autre sens : c'est ce qui
    produit les faux conflits que la comparaison canonique doit ignorer.

    survey_ids place sur l'etage la liste des releves que ce terminal connait.
    Les deux cotes divergent donc reellement sur cet objet partage : c'est le
    conflit que --on-conflict union doit resoudre sans rien perdre.
    """
    murs = [WALLTYPE_BETON, WALLTYPE_PLACO]
    if ordre_inverse:
        murs = list(reversed(murs))

    return {
        "buildings.json": {"buildings": [
            {"id": BUILDING, "name": "Site de demonstration"},
        ]},
        "floors.json": {"floors": [
            {"id": FLOOR, "name": "Rez-de-chaussee",
             "buildingId": BUILDING, "floorPlanId": FLOORPLAN,
             "surveyIds": list(survey_ids)},
        ]},
        "floorPlans.json": {"floorPlans": [
            {"id": FLOORPLAN, "name": "RDC", "imageId": "plan-rdc",
             "width": 1200, "height": 800, "metersPerUnit": 0.05,
             "wallTypeIds": murs},
        ]},
        "wallTypes.json": {"wallTypes": [
            {"id": WALLTYPE_BETON, "name": "Beton 20 cm", "attenuation": 12.0},
            {"id": WALLTYPE_PLACO, "name": "Cloison placo", "attenuation": 3.0},
        ]},
        "tagKeys.json": {"tagKeys": [
            {"id": TAGKEY, "key": "Zone"},
        ]},
    }


def _cote(prefixe: str, survey_id: str, ap_commun: str, ap_propre: str,
          mesures: list[str], x0: int) -> dict:
    """Objets propres a un terminal."""
    docs = {
        f"survey-{survey_id}.json": {"dataPoints": [
            {"id": m, "surveyId": survey_id, "floorPlanId": FLOORPLAN,
             "location": {"x": x0 + i * 12, "y": 300 + (i % 7) * 20},
             "timestamp": 1_700_000_000 + i * 3,
             "measuredRadios": [
                 {"accessPointId": ap_commun, "rssi": -52 - (i % 11)},
                 {"accessPointId": ap_propre, "rssi": -61 - (i % 9)},
             ]}
            for i, m in enumerate(mesures)
        ]},
        "surveys.json": {"surveys": [
            {"id": survey_id, "name": f"Releve {prefixe}",
             "floorPlanId": FLOORPLAN,
             "dataPointIds": list(mesures)},
        ]},
        "accessPoints.json": {"accessPoints": [
            # Meme MAC des deux cotes, identifiant different : c'est le
            # doublon inter-session benin.
            {"id": ap_commun, "name": "AP-CORE-01", "mac": MAC_PARTAGEE,
             "vendor": "Demo", "floorPlanId": FLOORPLAN},
            {"id": ap_propre, "name": f"AP-{prefixe.upper()}-02",
             "mac": f"00:11:22:33:44:{'66' if prefixe == 'tel' else '77'}",
             "vendor": "Demo", "floorPlanId": FLOORPLAN},
        ]},
    }
    docs["project.json"] = _project(
        "Projet de demonstration", "99999999-9999-4999-8999-999999999999")
    return docs


def _ecrire(path: str, docs: dict[str, dict], image: bytes) -> None:
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name, doc in docs.items():
            z.writestr(name, json.dumps(doc, ensure_ascii=False, indent=1))
        z.writestr("image-plan-rdc", image)


def main() -> int:
    os.makedirs(OUT, exist_ok=True)
    # Faux plan : quelques octets constants, identiques des deux cotes pour
    # que le preflight considere qu'il s'agit bien du meme plan.
    image = b"FIXTURE-PLAN-RDC-" + b"\x00" * 64

    tel = _tronc_commun(ordre_inverse=False, survey_ids=[TEL_SURVEY])
    tel.update(_cote("tel", TEL_SURVEY, TEL_AP_COMMUN, TEL_AP_PROPRE,
                     TEL_MESURES, x0=100))

    tab = _tronc_commun(ordre_inverse=True, survey_ids=[TAB_SURVEY])
    tab.update(_cote("tab", TAB_SURVEY, TAB_AP_COMMUN, TAB_AP_PROPRE,
                     TAB_MESURES, x0=700))

    _ecrire(os.path.join(OUT, "telephone.esx"), tel, image)
    _ecrire(os.path.join(OUT, "tablette.esx"), tab, image)

    print(f"Ecrit : {os.path.join(OUT, 'tablette.esx')}")
    print(f"Ecrit : {os.path.join(OUT, 'telephone.esx')}")
    print("\nEnchainement de test :")
    print("  python esx_diff.py tests/fixtures/tablette.esx "
          "tests/fixtures/telephone.esx")
    print("  python esx_merge.py merge tests/fixtures/tablette.esx "
          "tests/fixtures/telephone.esx -o fusion.esx --on-conflict union")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
