#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
smoke_test — verifie la chaine complete sur des fixtures synthetiques.

    python tests/smoke_test.py

Genere deux .esx forkes, lance le diagnostic, refuse la fusion en mode par
defaut, puis fusionne en mode union et controle le resultat. Aucun fichier
reel n'est touche.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
FIXTURES = os.path.join(HERE, "fixtures")
TAB = os.path.join(FIXTURES, "tablette.esx")
TEL = os.path.join(FIXTURES, "telephone.esx")

echecs: list[str] = []


def verifier(condition: bool, libelle: str) -> None:
    print(f"  [{'ok' if condition else 'ECHEC'}] {libelle}")
    if not condition:
        echecs.append(libelle)


def lancer(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, *args], cwd=ROOT,
                          capture_output=True, text=True)


def main() -> int:
    print("1. Generation des fixtures")
    r = lancer(os.path.join("tests", "make_fixtures.py"))
    verifier(r.returncode == 0, "make_fixtures s'execute")
    verifier(os.path.exists(TAB) and os.path.exists(TEL), "les deux .esx existent")

    print("\n2. Inventaire")
    r = lancer("esx_merge.py", "inspect", TAB)
    verifier(r.returncode == 0, "inspect s'execute")
    verifier("References orphelines : 0" in r.stdout,
             "la base ne contient aucune reference orpheline")

    print("\n3. Diagnostic prealable")
    r = lancer("esx_diff.py", TAB, TEL)
    verifier(r.returncode == 0, "esx_diff s'execute")
    verifier("1  identiques a l'ordre de serialisation pres" in r.stdout,
             "le faux conflit du a l'ordre des listes est absorbe")
    verifier("1  conflits reels de contenu" in r.stdout,
             "le conflit reel est detecte")
    verifier("keep-a perdrait ces donnees" in r.stdout,
             "l'impact de keep-a est signale")

    print("\n4. Refus en mode par defaut")
    with tempfile.TemporaryDirectory() as tmp:
        out = os.path.join(tmp, "fusion.esx")
        r = lancer("esx_merge.py", "merge", TAB, TEL, "-o", out)
        verifier(r.returncode != 0, "la fusion est refusee sans arbitrage")
        verifier(not os.path.exists(out), "aucun fichier n'a ete ecrit")

    print("\n5. Simulation en mode union")
    with tempfile.TemporaryDirectory() as tmp:
        out = os.path.join(tmp, "fusion.esx")
        r = lancer("esx_merge.py", "merge", TAB, TEL, "-o", out,
                   "--on-conflict", "union")
        verifier(r.returncode == 0, "la simulation aboutit")
        verifier(not os.path.exists(out),
                 "le dry-run n'ecrit toujours pas le projet")
        verifier("doublon(s) potentiel(s) sur 'mac'" in r.stdout,
                 "l'AP vu par les deux terminaux est signale comme doublon")

    print("\n6. Fusion effective")
    with tempfile.TemporaryDirectory() as tmp:
        out = os.path.join(tmp, "fusion.esx")
        r = lancer("esx_merge.py", "merge", TAB, TEL, "-o", out,
                   "--on-conflict", "union", "--apply")
        verifier(r.returncode == 0, "la fusion s'applique")
        verifier(os.path.exists(out), "le projet fusionne est ecrit")

        with zipfile.ZipFile(out) as z:
            surveys = [n for n in z.namelist() if os.path.basename(n).startswith("survey-")]
            floor = json.loads(z.read("floors.json"))["floors"][0]
            aps = json.loads(z.read("accessPoints.json"))["accessPoints"]

        verifier(len(surveys) == 2, "les deux sessions de releve sont presentes")
        verifier(len(floor.get("surveyIds", [])) == 2,
                 "union a conserve les references des deux sessions")
        verifier(len(aps) == 4, "les points d'acces des deux cotes sont presents")

        rapport = out + ".rapport.json"
        verifier(os.path.exists(rapport), "le rapport JSON est produit")
        if os.path.exists(rapport):
            with open(rapport, encoding="utf-8") as fh:
                data = json.load(fh)
            verifier(data.get("applique") is True,
                     "le rapport trace que la fusion a ete appliquee")
            verifier(bool(data.get("sortie", {}).get("sha256")),
                     "le rapport porte l'empreinte du fichier produit")

    print()
    if echecs:
        print(f"{len(echecs)} verification(s) en echec :")
        for e in echecs:
            print(f"  - {e}")
        return 1
    print("Toutes les verifications passent.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
